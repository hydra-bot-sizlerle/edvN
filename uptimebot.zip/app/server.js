require("express")().listen(1343);

const db = require("quick.db");
const discord = require("discord.js");
const client = new discord.Client({ disableEveryone: true });
client.login("NjY1NTIwODExODE3NTY2MjE5.Xhm0jg.ykkceP-1fFUcRr59KpS_uB2JX80");
const fetch = require("node-fetch");
const fs = require('fs')

setInterval(() => {
  var links = db.get("linkler");
  if(!links) return;
  var linkA = links.map(c => c.url)
  linkA.forEach(link => {
    try {
      fetch(link)
    } catch(e) { console.log("" + e) };
  })
  console.log("Tüm Botlar Uptime Edildi!")
}, 90000)

client.on("ready", () => {
if(!Array.isArray(db.get("linkler"))) {
db.set("linkler", [])
}
})

client.on("ready", () => {
  client.user.setActivity(`u.help | All links have been reset please re-add | 24/12/2020`)
  console.log(`[✔] Başarılı! Veritabanına Bağlandım.`)
})


client.on("message", message => {
  if(message.author.bot) return;
  var spl = message.content.split(" ");
  if(spl[0] == "u.add") {
  var link = spl[1]
  fetch(link).then(() => {
    if(db.get("linkler").map(z => z.url).includes(link)) return message.channel.send("<a:hayir:736207425928953880> `This link is available in the system.`")
    message.channel.send("<a:evet:736207256273682533> `I've Arranged It Successfully!`");
    db.push("linkler", { url: link, owner: message.author.id})
  }).catch(e => {
    return message.channel.send("<a:hayir:736207425928953880> `Please write a valid link so I can add it to the system! [u.add Glitch Link]`");
  })
  }
})


client.on("message", message => {
  if(message.author.bot) return;
  var spl = message.content.split(" ");
  if(spl[0] == "u.count") {
  var link = spl[1]
 message.channel.send(`<a:uptime:759142704029892659> **Total Uptimes:** ${db.get("linkler").length} / 2000`)
 message.channel.send(`<a:servers:759142667555700809> **Servers:** ${client.guilds.size}`)



}})



const Discord = require('discord.js');

client.on("message", message => {
  if(message.author.bot) return;
    var spl = message.content.split(" ");
  if(spl[0] == "u.help") {
let embed = new Discord.RichEmbed()
.setColor('#36393F')
.addField(` <a:emoji2:735936467012026469>    ‧   Uptime Commands`,`឵឵
<a:komut:764191945077424170>  ‧  **u.add\** - Adds the link you specified to the system.
<a:komut:764191945077424170>  ‧  **u.count\** - Shows the number of connections in the system.
<a:komut:764191945077424170>  ‧  **u.info\** - It explains how to add a link to the system.
឵
`)
 
.setThumbnail(client.user.avatarURL)
 .setImage('https://cdn.discordapp.com/attachments/757633950507204619/770345474871525448/standard_28.gif')
   .addField("<a:emoji7:735938265353552074>   ‧   Links", ` \n[Invite](https://discord.com/oauth2/authorize?client_id=665520811817566219&scope=bot&permissions=8)` + "**  **" + `\n`  + "**  **" + ` `, false)
return message.channel.send(embed);
    }
 
})


/*client.on("message", message => {
  if(message.author.bot) return;
    var spl = message.content.split(" ");
  if(spl[0] == "u.help") {
message.channel.send(`**Uptime Bot Commands v1.0**

\`u.help\` - Displays the help menu.
\`u.add\` - Adds the link you specified to the system.
\`u.say\` - It shows the number of links in the system.

2020 © Uptime | Coded by MertBhey, Edited by Alfonzo.
`)
  }
 
})*/


client.on("message", async message => {

  if(!message.content.startsWith("u.eval")) return;
  if(!["",""].includes(message.author.id)) return;
  var args = message.content.split("u.eval")[1]
  if(!args) return message.channel.send("<:asuna_no:732219380795965471> ..")
  
      const code = args
    
    
      function clean(text) {
          if (typeof text !== 'string')
              text = require('util').inspect(text, { depth: 3 })
          text = text
              .replace(/`/g, '`' + String.fromCharCode(8203))
              .replace(/@/g, '@' + String.fromCharCode(8203))
          return text;
      };
  
      var evalEmbed = ""
      try {
          var evaled = await clean(await eval(await code));
          if (evaled.constructor.name === 'Promise') evalEmbed = `\`\`\`\n${evaled}\n\`\`\``
          else evalEmbed = `\`\`\`js\n${evaled}\n\`\`\``
          
  if(evaled.length < 1900) { 
     message.channel.send(`\`\`\`js\n${evaled}\`\`\``);
  } else {
    var hast = await require("hastebin-gen")(evaled, { url: "https://hasteb.in" } )
  message.channel.send(hast)
  }
      } catch (err) {
          message.channel.send(`\`\`\`js\n${err}\n\`\`\``);
      }
  })
  
  const log = message => {
  console.log(`${message}`);
}
  


client.on('guildCreate', async guild => { client.channels.get('770258047766757406').send(`${guild}, "isimli sunucuya eklendim!`)})
// atıldım
client.on('guildRemove', async guild => { client.channels.get('770258047766757406').send(`${guild}, isimli sunucudan atıldım.. :(`)})



client.on("message", message => {
  if(message.author.bot) return;
    var spl = message.content.split(" ");
  if(spl[0] == "u.info") {
let embed = new Discord.RichEmbed()
.setColor('#36393F')
.addField(`<a:emoji4:735937854718608423>    ‧   Uptime Bot Information`,`឵Your added bot takes place in our systems 24/7 without closing in any way. The connections in the system work 24/7 without any errors.
឵
`)
.addField(`<a:uptime:759142704029892659>    ‧   How do i add ?`, `

We click on the place in the picture below and click on the place marked with a red frame, copy the link in the opened tab and add it as u.add [Link].
឵
`)
.setThumbnail(client.user.avatarURL)
 .setImage('https://cdn.discordapp.com/attachments/757633950507204619/770350380973686804/Adsz.png')
   .addField("<a:emoji7:735938265353552074>   ‧   Links", ` \n[Invite](https://discord.com/oauth2/authorize?client_id=665520811817566219&scope=bot&permissions=8)` + "**  **" + `\n`  + "**  **" + ` `, false)
return message.channel.send(embed);
    }
 
})




